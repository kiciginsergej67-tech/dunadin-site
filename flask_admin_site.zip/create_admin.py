# Script to create an admin user. Run this once to add your admin account.
# Usage (recommended):
#   FLASK_ADMIN_USER=yourname FLASK_ADMIN_PASS=yourpassword python create_admin.py
import os
import sqlite3
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), 'app.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    return conn

def ensure_db():
    # create tables if missing (similar to app.init_db)
    with get_db() as conn:
        conn.executescript(""" 
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

def create_admin(username, password):
    pw_hash = generate_password_hash(password)
    with get_db() as conn:
        try:
            conn.execute('INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, 1)', (username, pw_hash))
            conn.commit()
            print('Admin user created:', username)
        except Exception as e:
            print('Could not create admin user:', e)

if __name__ == '__main__':
    user = os.environ.get('FLASK_ADMIN_USER') or input('Admin username: ')
    pwd = os.environ.get('FLASK_ADMIN_PASS') or input('Admin password: ')
    ensure_db()
    create_admin(user, pwd)
