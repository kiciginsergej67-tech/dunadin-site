# Minimal Flask Admin Site

This is a small Flask project with:
- SQLite database (app.db)
- Admin user (create with create_admin.py)
- Admin dashboard at /admin (requires admin login)
- Simple posts management from admin panel

## Setup (local)
1. Create a virtual environment:
   python -m venv venv
   source venv/bin/activate   # on Windows: venv\Scripts\activate

2. Install requirements:
   pip install -r requirements.txt

3. Create an admin user:
   FLASK_ADMIN_USER=yourname FLASK_ADMIN_PASS=yourpass python create_admin.py
   or run: python create_admin.py and follow prompts

4. Run the app:
   export FLASK_SECRET='choose-a-secret'
   python app.py
   Open http://127.0.0.1:5000

## Notes
- This is a demo starter. Before deploying to production:
  * Use a strong secret key
  * Disable debug mode
  * Use HTTPS
  * Consider a proper user management and CSRF protection (e.g., Flask-WTF)
